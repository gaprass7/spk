
<?php $__env->startSection('content'); ?>
<?php
$ar_kriteria = App\Models\Kriteria::all();
?>

<div class="col-md-4">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Add Keterangan</h4>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('bobot.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row mb-1">
                    <div class="col-sm-12 mb-4">
                        <select class="form-control" name="kriteria_id">
                            <option selected>-- Pilih Kriteria --</option>
                            <?php $__currentLoopData = $ar_kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kri->id); ?>"><?php echo e($kri->kriteria); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-sm-12">
                        <input type="text" placeholder="bobot" class="form-control <?php $__errorArgs = ['bobot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="bobot" value="<?php echo e(old('bobot')); ?>">
                        <?php $__errorArgs = ['bobot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"> 
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div><br>
                <div class="text-center">
                    <button class="btn btn-secondary"><a style="color:white;" title="Batal"
                            href="<?php echo e(url('')); ?>">Batal</a></button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php echo $__env->make('bobot.data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\integrasi\admin-rental\resources\views/bobot/index.blade.php ENDPATH**/ ?>