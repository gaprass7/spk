
<div class="col-md-8">
    <?php echo $__env->make('template.alertsukses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-header">
            <h4 class="card-title"> Tabel Data Nilai </h4>
        </div>
        <div class="mt-8" style="width:550px; margin-left:10px;">
            <a class="btn btn-sm" title="Tambah Nasabah Baru" style="background-color: blue; color: white;"
                href="<?php echo e(route('dataNilai.index')); ?>">
                <i class="bi bi-plus-circle-fill"> Add Nilai</i>
            </a>
            <a class="btn btn-danger btn-sm" title="Export to PDF Menu" href=" <?php echo e(url('menu-pdf')); ?>">
                <i class="bi bi-file-earmark-pdf-fill"> Export to PDF</i>
            </a>
            <a class="btn btn-success btn-sm" title="Export to Excel Menu" href=" <?php echo e(url('menu-excel')); ?>">
                <i class="bi bi-file-excel"> Export to Excel</i>
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead class=" text-primary">
                        <th>No</th>
                        <th>Nama</th>
                        <th>C1</th>
                        <th>C2</th>
                        <th>C3</th>
                        <th>C4</th>
                        <th>C5</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php
                        $no=1;
                        ?>
                        <?php $__currentLoopData = $dataNilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->nama); ?></td>
                            <td><?php echo e($row->nilai1); ?></td>
                            <td><?php echo e($row->nilai2); ?></td>
                            <td><?php echo e($row->nilai3); ?></td>
                            <td><?php echo e($row->nilai4); ?></td>
                            <td><?php echo e($row->nilai5); ?></td>
                            <td>
                                <form method="POST" id="formDelete" action="<?php echo e(route('dataNilai.destroy',$row->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a class="btn btn-dark btn-sm" title="Detail Menu"
                                        href=" <?php echo e(route('dataNilai.show',$row->id)); ?>">
                                        <i class="fa fa-eye"></i>
                                    </a>


                                    <a class="btn btn-warning btn-sm" title="Ubah Menu"
                                        href=" <?php echo e(route('dataNilai.edit',$row->id)); ?>">
                                        <i class="fa fa-pencil"></i>
                                    </a>

                                    <button type="submit" class="btn btn-danger btn-sm btnDelete" title="Hapus Menu">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot style="font-weight: bold; text-align:center; background-color: #a1a191;">
                        <tr>
                            <td colspan="2">Nilai Tertinggi</td>
                            <td><?php echo e($max_nilai1); ?></td>
                            <td><?php echo e($max_nilai2); ?></td>
                            <td><?php echo e($max_nilai3); ?></td>
                            <td><?php echo e($max_nilai4); ?></td>
                            <td><?php echo e($max_nilai5); ?></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\integrasi\spk-santri\resources\views/dataNilai/data.blade.php ENDPATH**/ ?>