<div class="col-md-8">
    <?php echo $__env->make('template.alertsukses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-header">
            <h4 class="card-title"> Tabel Keterangan</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead class=" text-primary">
                        <th>No</th>
                        <th>Keterangan</th>
                        <th>aksi</th>
                    </thead>
                    <tbody>
                        <?php
                        $no=1;
                        ?>
                        <?php $__currentLoopData = $keterangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->keterangan); ?></td>
                            <td>
                                <form method="POST" id="formDelete" action="<?php echo e(route('keterangan.destroy',$row->id)); ?>">
                                
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a class="btn btn-info btn-sm" title="Detail Menu" href=" <?php echo e(route('keterangan.show',$row->id)); ?>">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                
                                
                                    <a class="btn btn-warning btn-sm" title="Ubah Menu" href=" <?php echo e(route('keterangan.edit',$row->id)); ?>">
                                        <i class="fa fa-pencil"></i>
                                    </a>
                                
                                    <button type="submit" class="btn btn-danger btn-sm btnDelete" title="Hapus Nasabah">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\integrasi\spk-santri\resources\views/keterangan/data.blade.php ENDPATH**/ ?>