
<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title"> Tabel Ranking Nilai Santri</h4>
        </div>
        <div class="mt-8" style="width:550px; margin-left:10px;">
            <a class="btn btn-sm" title="Tambah Nasabah Baru" style="background-color: blue; color: white;"
                href="<?php echo e(route('dataNilai.index')); ?>">
                <i class="bi bi-plus-circle-fill"> Add Nilai</i>
            </a>
            <a class="btn btn-danger btn-sm" title="Export to PDF Menu" href=" <?php echo e(url('/generate-pdf')); ?>">
                <i class="bi bi-file-earmark-pdf-fill"> Export to PDF</i>
            </a>
            <a class="btn btn-success btn-sm" title="Export to Excel Menu" href=" <?php echo e(url('menu-excel')); ?>">
                <i class="bi bi-file-excel"> Export to Excel</i>
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead class=" text-primary" style="border-bottom: 2px solid black; text-align: center;" <th>
                        </th>
                        <th>No</th>
                        <th>Nama</th>
                        <th>C1</th>
                        <th>C2</th>
                        <th>C3</th>
                        <th>C4</th>
                        <th>C5</th>
                        <th>Nilai</th>
                        <th>Keterangan</th>
                    </thead>
                    <tbody>
                        <?php
                        $no=1;
                        ?>
                        <?php $__currentLoopData = $dataNilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr
                            style="background-color: <?php echo e(($no <= 50) ? 'rgba(0, 128, 0, 0.1)' : 'rgba(255, 0, 0, 0.1)'); ?>; }}; text-align: center; vertical-align: middle;">
                            <td><?php echo e($no++); ?></td>
                            <td style="text-align: left;"><?php echo e($row->nama); ?></td>
                            <td><?php echo e($row->nilai1); ?></td>
                            <td><?php echo e($row->nilai2); ?></td>
                            <td><?php echo e($row->nilai3); ?></td>
                            <td><?php echo e($row->nilai4); ?></td>
                            <td><?php echo e($row->nilai5); ?></td>
                            <td><?php echo e($row->total); ?></td>
                            <td>
                                <span style="display: inline-block; width: 100%;">
                                    <?php echo e(($no <= 51) ? 'Diterima' : 'Belum diterima'); ?> </span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\integrasi\spk-santri\resources\views/hasil/index.blade.php ENDPATH**/ ?>