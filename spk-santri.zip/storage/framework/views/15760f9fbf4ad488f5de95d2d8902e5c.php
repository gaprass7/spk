<div class="col-md-8">
    <?php echo $__env->make('template.alertsukses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-header">
            <h4 class="card-title"> Tabel Bobot</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead class=" text-primary">
                        <th>No</th>
                        <th>Keterangan</th>
                        <th>Bobot</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php
                        $no=1;
                        ?>
                        <?php $__currentLoopData = $bobot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->kriteria->kriteria); ?></td>
                            <td><?php echo e($row->bobot); ?></td>
                            <td>
                                <form method="POST" id="formDelete" action="<?php echo e(route('bobot.destroy',$row->id)); ?>">
                            
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a class="btn btn-info btn-sm" title="Detail Menu" href=" <?php echo e(route('bobot.show',$row->id)); ?>">
                                        <i class="fa fa-eye"></i>
                                    </a>
                            
                            
                                    <a class="btn btn-warning btn-sm" title="Ubah Menu" href=" <?php echo e(route('bobot.edit',$row->id)); ?>">
                                        <i class="fa fa-pencil"></i>
                                    </a>
                            
                                    <button type="submit" class="btn btn-danger btn-sm btnDelete" title="Hapus Nasabah">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\integrasi\spk-santri\resources\views/bobot/data.blade.php ENDPATH**/ ?>